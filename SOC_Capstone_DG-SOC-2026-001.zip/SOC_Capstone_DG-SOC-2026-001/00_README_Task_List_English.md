# Task List — SOC Final Capstone (English)

1. **Build the SOC Lab** — Ubuntu server, Wazuh Manager, Agent, Dashboard, Snort IDS, test endpoint. Verify all components working. (Report Sections 2–5)
2. **Simulate a Security Incident** — Scenario D: Multi-Stage Incident (Recon → Authentication → File Activity). (Section 6)
3. **Detection** — Detection time, source/destination IPs, user, protocol, port, Snort SID, Wazuh Rule ID, severity, detection source, why suspicious. (Section 7)
4. **Full Incident Investigation** — What/when/which system/IP/account/alerts/rules/evidence, True vs False Positive, potential impact. (Section 8)
5. **Correlate Snort + Wazuh** — Incident timeline table + why combined visibility is better. (Section 9)
6. **IOC & Evidence Collection** — IOC table: IP, username, port, protocol, file/path, rule ID/SID, timestamp. (Section 10)
7. **Incident Response** — 6-phase plan: Preparation, Identification, Containment, Eradication, Recovery, Lessons Learned. (Section 11)
8. **Final SOC Incident Ticket** — DG-SOC-2026-001 with all required fields. (Section 12)
9. **SOC Metrics** — Events, alerts, TP/FP, severity counts, Snort/Wazuh detections, top IOC. (Section 13)
10. **Final SOC Analyst Reflection** — Learning outcomes, challenges, solutions, improvements. (Section 14 + Appendix A)

## Deliverables
- PDF/Word Report: 15+ pages (this .docx → export to PDF)
- PPT: 12 slides
- LinkedIn Post: LinkedIn_Post.txt
- Evidence: evidence_images/ (21 images)
